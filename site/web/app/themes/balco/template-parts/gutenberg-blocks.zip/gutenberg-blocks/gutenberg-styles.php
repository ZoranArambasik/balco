<?php 
echo '<style>
    .wp-block {max-width: 1220px !important; padding: 0px 10px !important;}
</style>';
?>
